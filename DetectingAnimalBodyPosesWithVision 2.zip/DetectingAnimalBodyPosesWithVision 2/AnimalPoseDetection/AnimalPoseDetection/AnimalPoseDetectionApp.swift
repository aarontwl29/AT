/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The app's body.
*/

import SwiftUI

@main
struct AnimalPoseDetectionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
